<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Commonmysqlmodel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // All MySQl DB Operations Performs Here except CRUD Operations.
    public function getMasterList($arguments){
        
        if(isset($arguments['table']) && $arguments['table']){

            $table      = $arguments['table'];

            $tableAlias = (isset($arguments['tableAlias']) && $arguments['tableAlias']) 
                            ? " AS ".$arguments['tableAlias']
                            : ''; 

            $returnData = (isset($arguments['returnData']) && $arguments['returnData']) 
                            ? $arguments['returnData']
                            : '*';
            
            $dbCondition= (isset($arguments['dbCondition']) && count($arguments['dbCondition'])) 
                            ? $arguments['dbCondition']
                            : array();

            $joins      = (isset($arguments['joins']) && count($arguments['joins'])) 
                            ? $arguments['joins']
                            : array();

            $like       = (isset($arguments['like']) && count($arguments['like'])) 
                            ? $arguments['like']
                            : array();

            $orLike     = (isset($arguments['orLike']) && count($arguments['orLike'])) 
                            ? $arguments['orLike']
                            : array();

            $notLike    = (isset($arguments['notLike']) && count($arguments['notLike'])) 
                            ? $arguments['notLike']
                            : array();

            $orderBy    = (isset($arguments['orderBy']) && count($arguments['orderBy'])) 
                            ? $arguments['orderBy']
                            : array();

            $groupBy    = (isset($arguments['groupBy']) && count($arguments['groupBy'])) 
                            ? $arguments['groupBy']
                            : array();

            $limit      = (isset($arguments['limit']) && $arguments['limit']) 
                            ? explode(',',$arguments['limit'])
                            : array(); 

            $returnType = (isset($arguments['returnType']) && $arguments['returnType']) 
                            ? $arguments['returnType']
                            : 0;

            $formatType = (isset($arguments['formatType']) && $arguments['formatType']) 
                            ? $arguments['formatType']
                            : 'array_format';

            $having    = (isset($arguments['having'])) ? $arguments['having'] : array();

            $not_in    = (isset($arguments['not_in'])) ? $arguments['not_in'] : array();

            $where_or    = (isset($arguments['dbWhereOr'])) ? $arguments['dbWhereOr'] : array();


            $dbFindInSet = (isset($arguments['dbFindInSet']) && count($arguments['dbFindInSet'])) 
                            ? $arguments['dbFindInSet']
                            : array();


            $this->db->select($returnData);
            $this->db->from($this->db->dbprefix($table).$tableAlias);
            
            if(!empty($dbFindInSet))
            {
                $findQuery = '';
                $first = 1;
                foreach ($dbFindInSet as $key => $findval) {
                        $i=1;
                        $length = count($findval);
                        if( $first!=1 && $first <= count($dbFindInSet))
                        {
                            $findQuery .= ' OR';
                        }
                        foreach ($findval as $val) {
                        if($length==1)
                        {
                            $findQuery .= ' FIND_IN_SET('.$val.','.$key.') != 0 ';
                        }
                        else
                        {
                            $findQuery .= ' FIND_IN_SET('.$val.','.$key.')';
                            if($i < $length)
                            {
                                $findQuery .= ' OR';
                            }
                        }
                        $i++;
                    }
                    $first++;
                }

                $this->db->or_where($findQuery);
            }

            
            if(!empty($where_or))
            {
                    $orQuery = '';
                    $total = count($where_or);
                    $i=1;
                    $orQuery  = '';
                    if($total > 1)
                    {
                        $orQuery = ' ( ';
                    }
                    foreach ($where_or as $key => $value) {
                        
                        $loc   = $key;
                        $id    = $value;
                        $orQuery .= $loc . "'".$id."'";

                        if($i < $total)
                        {
                            $orQuery .= ' OR ';
                        }
                        if($i==$total)
                        {
                           $orQuery .= ' ) '; 
                        }
                        $i++;
                    }
                    $this->db->where($orQuery);
            }

            if(!empty($dbCondition))
            {
               $dbCondition ? $this->db->where($dbCondition) : '';
            }
            if(count($joins)){
                foreach ($joins as $field) {
                    if(isset($field['table'])){
                        $type = isset($field['type']) ? $field['type'] : '';
                        $match = isset($field['match']) ? $field['match'] : '';
                        $this->db->join($this->db->dbprefix($field['table'])." AS ".$field['alias'],$match,$type);
                    }
                }
            }

            $like ? $this->db->like($like) : '';

            $orLike ? $this->db->or_like($orLike) : '';

            $notLike ? $this->db->not_like($notLike) : '';

            if(count($orderBy)){
                foreach ($orderBy as $field => $order) {
                    $this->db->order_by($field,$order);
                }
            }

            $groupBy ? $this->db->group_by($groupBy) : '';

            $having ? $this->db->having($having) : '';

            $not_in ? $this->db->where_not_in($not_in) : '';

            $limit ? (count($limit) > 1 ? $this->db->limit($limit['0'],$limit['1']) : $this->db->limit($limit['0'])) : '';

            $query  = $this->db->get();

            $queryResult = $returnType ? ($returnType == 1 ? $query->row_array() : $query->num_rows()) : $query->result_array();

            $finalResult = $formatType ? ($formatType == 'array_format' ? $queryResult : json_encode($queryResult)) : json_encode($queryResult);


            //for check last execute query
            //echo $this->db->last_query(); die;
        
            return $finalResult;
            //return $arguments;
        }

    }

    public function count_all($table)
    {
        if($table!='')
        {
            //$this->db->where('is_deleted',1);

            $this->db->from($table);
            $result = $this->db->count_all_results();
            return $result;
        }
    }

    // Basic DB CRUD Operations
    public function dbActionScript($arguments){

        if(isset($arguments['table']) && $arguments['table']){

            $table      = $arguments['table'];

            $action = (isset($arguments['action']) && $arguments['action']) 
                            ? $arguments['action']
                            : '';

            $returnData  = array();

            if($action == 'add'){
                $result = $this->db->insert($this->db->dbprefix($table),$arguments['dbData']);
                $returnData = array(
                    'result'        =>  $result,
                    'insertId'      =>  $result ? $this->db->insert_id() : 0,
                    'error'         =>  $this->db->error()
                );
            }else if($action == 'update'){
                $this->db->where($arguments['dbCondition']);
                $result = $this->db->update($this->db->dbprefix($table),$arguments['dbData']);
                $returnData = array(
                    'result'        =>  $result,
                    'affectedRows'  =>  $result ? $this->db->affected_rows() : 0,
                    'error'         =>  $this->db->error()
                );
            }else if($action == 'delete'){
                $this->db->where($arguments['dbCondition']);
                $result = $this->db->delete($this->db->dbprefix($table));
                $returnData = array(
                    'result'        =>  $result,
                    'affectedRows'  =>  $result ? $this->db->affected_rows() : 0,
                    'error'         =>  $this->db->error()
                );
            }

            return $returnData;

        }
        
    }

    // Get all colleges list based by masters
    public function getCollegesList($dbCondition=array(), $limit='',$start=''){
        
        $joins  =   array(   
                        array(
                            'table' => 'course',
                            'alias' => 'CO',
                            'match' => 'CO.collegeId = C.collegeId',
                            'type'  => 'INNER'
                        ),
                        array(
                            'table' => 'studylevel',
                            'alias' => 'SL',
                            'match' => 'SL.studyLevelId = CO.studyLevelId',
                            'type'  => 'INNER'
                        ),
                        array(
                            'table' => 'studyarea',
                            'alias' => 'SA',
                            'match' => 'SA.studyAreaId = CO.studyAreaId',
                            'type'  => 'INNER'
                        ),
                        array(
                            'table' => 'branches',
                            'alias' => 'B',
                            'match' => 'CO.branchId = B.branchId',
                            'type'  => 'INNER'
                        ),
                        array(
                            'table' => 'city',
                            'alias' => 'CI',
                            'match' => 'C.cityId = CI.cityId',
                            'type'  => 'LEFT'
                        ),
                        array(
                            'table' => 'state',
                            'alias' => 'S',
                            'match' => 'C.stateId = S.stateId',
                            'type'  => 'LEFT'
                        ),
                        array(
                            'table' => 'country',
                            'alias' => 'COU',
                            'match' => 'C.countryId = COU.countryId',
                            'type'  => 'INNER'
                        ),
                        array(
                            'table' => 'institution',
                            'alias' => 'I',
                            'match' => 'C.institutionType = I.institutionId',
                            'type'  => 'INNER'
                        )
                    );
        if(!empty($dbCondition['collegeOrder']))
        {
            $collegeOrder = isset($dbCondition['collegeOrder']['collegeOrderType']) ? $dbCondition['collegeOrder']['collegeOrderType'] : '';
            $orderBy = array('C.collegeName' => $collegeOrder);
        }
        if(!empty($dbCondition['ratingOrder']))
        {
            $ratingOrder = isset($dbCondition['ratingOrder']['ratingsOrderType']) ? $dbCondition['ratingOrder']['ratingsOrderType'] : '';
            $orderBy = array('C.setara' => $ratingOrder);
        }
        if(empty($dbCondition['ratingOrder']) && empty($dbCondition['collegeOrder']))
        {
            $orderBy = array('C.collegeName' => 'ASC');
        }
        $basicCondition['COMMON'] = array(
            'C.status ='        => 0,
            'C.isDeleted ='     => 0
        );

        $dbCondition = array_merge($basicCondition,$dbCondition);

        $arguments  =   array(
            'table'        =>  "college",
            'tableAlias'   =>  "C",
            'returnData'   =>  "DISTINCT(C.collegeId), C.collegeName, C.description, C.logo, CI.name as city, I.name as institutionTypeName, S.name as state, C.establishedYear, C.officialWebsite, C.address, C.email1, COU.name as country, C.phoneNumber1, C.fbUrl, C.twitterUrl, C.facility, C.cityId, C.institutionType, C.seoURI, C.postalCode, C.rate, C.setara, SL.seoURI as levelUri, SA.seoURI as areaUri, C.collegeCode,C.seoTitle,C.seoDescription,C.campusSize,C.CampusLocationDescription, C.campusLocationDescription2, C.isClosed,C.collegeCode",
            'dbCondition'  =>  $dbCondition ? $dbCondition : '',
            'joins'        =>  $joins,
            'groupBy'      =>  array('C.collegeId'),
            'orderBy'      =>  $orderBy,
            'limit'        =>  $limit ? $limit : '',
            'returnType'   =>  isset($dbCondition['COMMON']['C.collegeId=']) ? 1 : '',
        );
        
        $collegesList     = $this->getMasterList($arguments);
        return $collegesList;
    }
    public function udProcess($action_type,$tname,$colname,$vals,$status)
    {
            if($action_type=='delete')
            {
                $id             = explode(',', $vals);
                $data           = array('is_deleted'=> 0);
                $this->db->where_in($colname,$id);
                $query          = $this->db->update($tname,$data);
                if($query)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else if($action_type=='status')
            {
                $id             = explode(',', $vals);
                $data           = array('status'=> $status);
                $this->db->where_in($colname,$id);
                $query          = $this->db->update($tname,$data);
                if($query)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else{
                    return false;
            }      
    }

   
   
}