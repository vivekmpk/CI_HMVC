<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcomemodel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function getData()
    {
    	$query 	= $this->db->get('wp_posts');
    	$result = $query->result_array();
    	return $result; 
    }
    

}