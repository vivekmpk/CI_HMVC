<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	function __construct()
    {
    	parent::__construct();
        $this->load->model('common/commonmysqlmodel','commonmysql');
        $this->load->model('welcomemodel');

    }
	public function index()
	{
		$data =	$this->welcomemodel->getData();
		$this->load->view('welcome_message');
	}
}
