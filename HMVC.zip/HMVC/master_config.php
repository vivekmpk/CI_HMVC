<?php
date_default_timezone_set('Asia/Singapore');
define('SITEURL','http://localhost/HMVC/');
define('CURR_DATE', date('Y-m-d'));
define('CURR_DATE_TIME', date('Y-m-d H:i:s'));
//MYSQL DATABASE CONNECTION
define('hostname','localhost');
define('username','root');
define('password','');
define('dbname','wp_cf7database');
define('dbprefix','');

?>